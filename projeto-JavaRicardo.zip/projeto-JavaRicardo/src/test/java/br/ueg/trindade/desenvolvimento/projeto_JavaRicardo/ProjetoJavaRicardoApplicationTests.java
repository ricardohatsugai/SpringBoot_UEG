package br.ueg.trindade.desenvolvimento.projeto_JavaRicardo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoJavaRicardoApplicationTests {

	@Test
	void contextLoads() {
	}

}
